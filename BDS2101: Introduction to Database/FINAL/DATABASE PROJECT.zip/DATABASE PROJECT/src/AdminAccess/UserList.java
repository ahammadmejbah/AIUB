package AdminAccess;
import data.Conn;
import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


public class UserList implements  ActionListener {
    private JFrame frame;
    private JLabel l1,l2;
    private JTable table;
    private JButton removeButton,backButton;

    public UserList()
    {
        frame = new JFrame("User List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        /*
        String[][] userData = readUserDataFrom("src\\data\\userdata.txt");
        String[] collumNames = {"Name","E-mail","Password","Gender"};
        DefaultTableModel tableModel = new DefaultTableModel(userData,collumNames);

        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(137, 121, 491, 242);

        frame.add(scrollPane);

         */
        removeButton = new JButton("Remove User");
        removeButton.setBorder(null);
        removeButton.setBounds(200, 400, 180, 30);
        removeButton.addActionListener(this);
        frame.add(removeButton);

        backButton = new JButton("Back");
        backButton.setBorder(null);
        backButton.setBounds(550, 400, 100, 30);
        backButton.addActionListener(this);
        frame.add(backButton);

        l2 = new JLabel("User List");
        Font font = new Font("Times New Roman", Font.PLAIN, 48);
        l2.setFont(font);
        l2.setForeground(Color.decode("#0f0aa7"));
        l2.setBounds(282,14,185,57);
        frame.add(l2);

        ImageIcon BG = new ImageIcon("image/BG.png");
        l1 = new JLabel(BG);
        l1.setBounds(0,0,750,510);
        frame.add(l1);


        try
        {
            Conn conn = new Conn();

            ResultSet totalUserList = conn.s.executeQuery("SELECT * FROM registration");

            table = new JTable();

            table.setModel((DbUtils.resultSetToTableModel(totalUserList))); // database full table ekhane dekhbo
        }
        catch (Exception ar)
        {
            ar.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(120, 100, 491, 242);
        frame.add(scrollPane);





        frame.setSize(750,510);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setVisible(true);
    }


    private void updateSourceFile(String[][] data)
    {
        try (PrintWriter out = new PrintWriter(new FileWriter("userdata.txt")))
        {
            for (String[] row : data)
            {
                out.println(String.join(",", row));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }



    public void actionPerformed(ActionEvent e)
    {
        String txt = e.getActionCommand();

        if(txt.equals("Back"))
        {
            frame.dispose();
            new Adminpanel();
        }
        else if (txt.equals("Remove User"))
        {

        }


    }


    public static void main(String[] args) {
        new UserList();
    }

}
