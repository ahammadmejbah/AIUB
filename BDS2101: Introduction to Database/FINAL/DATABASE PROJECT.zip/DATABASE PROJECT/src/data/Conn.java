package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conn
{
    Connection c;
    public Statement s;

    public Conn()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // JAR FILE mysql connector java 8.0
            c = DriverManager.getConnection("jdbc:mysql:///BusTicketBuy", "root", "CodeWithFarhan");
            s = c.createStatement();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
