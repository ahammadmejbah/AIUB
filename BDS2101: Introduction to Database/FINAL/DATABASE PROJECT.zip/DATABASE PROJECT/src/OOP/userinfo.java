package OOP;
import GUI.*;
import data.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;

public class userinfo extends JFrame implements ActionListener
{
    private JLabel page_title, nameField, emailField, passwordField, genderField;

    private  JTextField tfEmail;
    private JButton b1,b2,b3,search;

    private JPanel P1,P2;






    public userinfo()
    {
        super("user info");
        this.setSize(750,510);
        setLocationRelativeTo(null);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);





        // ----------------- Panel Set Up ------------------------

        P1 = new JPanel();
        P1.setBounds(0,0,750,80);
        P1.setBackground(new Color(124,124,124));
        P1.setBorder(BorderFactory.createLineBorder(Color.black));
        P1.setLayout(null);


        P2 = new JPanel();
        P2.setBounds(0,80,750,430);
        P2.setBackground(new Color(218,227,243));
        P2.setBorder(BorderFactory.createLineBorder(Color.black));
        P2.setLayout(null);


        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());


        // ----------------- Panel 01 Set Up ------------------------

        page_title = new JLabel("User information");
        page_title.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,38));
        page_title.setForeground(Color.black);
        page_title.setBounds(20,22,480,35);
        P1.add(page_title);


        b1 = new JButton("Sign out");
        b1.setFont(new Font("Serif",Font.BOLD,20));
        b1.setBackground(Color.green);
        b1.setBounds(600, 20, 110, 35);
        b1.addActionListener(this);
        b1.setFocusable(false);
        b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(b1);



        // ----------------- Panel 02 Set Up ------------------------

        b2 = new JButton("Back");
        b2.setFont(new Font("Serif",Font.BOLD,20));
        b2.setBackground(Color.orange);
        b2.setBounds(40, 420, 100, 35);
        b2.addActionListener(this);
        b2.setFocusable(false);
        b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b2);


        b3 = new JButton("UPDATE PROFILE");
        b3.setFont(new Font("Serif",Font.BOLD,20));
        b3.setBackground(Color.pink);
        b3.setBounds(440, 420, 250, 35);
        b3.addActionListener(this);
        b3.setFocusable(false);
        b3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b3);


        JLabel searchEmail = new JLabel("Email");
        searchEmail.setBounds(28, 90, 100, 25);
        searchEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
        this.add(searchEmail);

        tfEmail = new JTextField();
        tfEmail.setBounds(90, 90, 150, 25);
        tfEmail.setBorder(null);
        tfEmail.setForeground(Color.red);
        tfEmail.setFont(new Font("Tahoma", Font.BOLD, 16));
        this.add(tfEmail);

        search = new JButton("Search");
        search.setBackground(Color.BLACK);
        search.setForeground(Color.WHITE);
        search.setBounds(280, 90, 120, 25);
        search.setBorder(null);
        search.addActionListener(this);
        this.add(search);


        //name
        JLabel l22 = new JLabel("Name: ");
        l22.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l22.setBounds(28,120,200,35);
        this.add(l22);

        nameField = new JLabel();
        nameField.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        nameField.setForeground(Color.black);
        nameField.setBounds(100,120,480,35);
        this.add(nameField);


        //email
        JLabel l33 = new JLabel("email: ");
        l33.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l33.setBounds(28,170,200,35);
        this.add(l33);


        emailField = new JLabel();
        emailField.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        emailField.setForeground(Color.black);
        emailField.setBounds(100,170,480,35);
        P2.add(emailField);


        //password
        JLabel l44 = new JLabel("Password: ");
        l44.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,18));
        l44.setBounds(28,220,200,35);
        this.add(l44);

        passwordField = new JLabel();
        passwordField.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        passwordField.setForeground(Color.black);
        passwordField.setBounds(126,220,480,35);
        P2.add(passwordField);


        //gender
        JLabel l55 = new JLabel("gender: ");
        l55.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l55.setBounds(28,270,200,35);
        this.add(l55);

        genderField = new JLabel();
        genderField.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        genderField.setForeground(Color.black);
        genderField.setBounds(100,270,480,35);
        P2.add(genderField);


        this.add(P1);
        this.add(P2);

        setVisible(true);

    }



    public void actionPerformed(ActionEvent ae){


        if(ae.getSource()==b1)
        {
            this.setVisible(false);
            new Login();
        }

        else if(ae.getSource()==b2)
        {
            Buses m = new Buses();
            this.setVisible(false);
            m.setVisible(true);
        }

        else if(ae.getSource()==b3)
        {
            this.setVisible(false);
            passwordChange p = new passwordChange();
            p.setVisible(true);
        }
        else if (ae.getSource() == search)
        {
            String email = tfEmail.getText();
            try
            {
                Conn conn = new Conn();

                String query = "SELECT * FROM registration WHERE email = '"+email+"' ";

                ResultSet rs = conn.s.executeQuery(query);

                if (rs.next())
                {
                    nameField.setText(rs.getString("name"));
                    emailField.setText(rs.getString("email"));
                    passwordField.setText(rs.getString("password"));
                    genderField.setText(rs.getString("gender"));
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Please enter correct Email ID !!");
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }


    }



    public static void main(String [] args)
    {
        userinfo l = new userinfo();

    }



}
