package OOP;
import GUI.Buses;
import data.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.ResultSet;

public class passwordChange extends JFrame implements ActionListener
{
    private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;

    private JButton back1,back2,continueButton,confirmButton;

    private JPanel P1,P2,P3;

    private JTextField emailField;

    private JPasswordField passwordField,newPasswordField,pa3;

    private JCheckBox c1;


    public passwordChange()
    {
        super("passwordChange");
        this.setSize(750,510);
        setLocationRelativeTo(null);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);




        // ----------------- Panel Set Up ------------------------

        P1 = new JPanel();
        P1.setBounds(0,0,750,70);
        P1.setBackground(new Color(118,113,113));
        P1.setBorder(BorderFactory.createLineBorder(Color.black));
        P1.setLayout(null);


        P2 = new JPanel();
        P2.setBounds(0,70,750,440);
        P2.setBackground(new Color(219,219,219));
        P2.setBorder(BorderFactory.createLineBorder(Color.black));
        P2.setLayout(null);


        P3 = new JPanel();
        P3.setBounds(0,70,750,440);
        P3.setBackground(new Color(219,219,219));
        P3.setBorder(BorderFactory.createLineBorder(Color.black));
        P3.setLayout(null);


        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());

        // ----------------- Panel 01 Set Up ------------------------

        l1 = new JLabel("Password Change");
        l1.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,31));
        l1.setForeground(Color.orange);
        l1.setBounds(20,22,480,35);
        P1.add(l1);




        // ----------------- Panel 02 Set Up ------------------------

        back1 = new JButton("Back");
        back1.setFont(new Font("Serif",Font.BOLD,20));
        back1.setBackground(Color.orange);
        back1.setBounds(40, 420, 100, 35);
        back1.addActionListener(this);
        back1.setFocusable(false);
        back1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(back1);


        continueButton = new JButton("continue");
        continueButton.setFont(new Font("Serif",Font.BOLD,20));
        continueButton.setBackground(Color.green);
        continueButton.setBounds(570, 420, 130, 35);
        continueButton.addActionListener(this);
        continueButton.setFocusable(false);
        continueButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(continueButton);




        l2 = new JLabel("Please verify yourself : ");
        l2.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,23));
        l2.setForeground(Color.black);
        l2.setBounds(65,130,480,35);
        P2.add(l2);



        //username
        l3 = new JLabel("Email : ");
        l3.setFont(new Font("Serif",Font.PLAIN,20));
        l3.setForeground(Color.black);
        l3.setBounds(155,210,200,35);
        P2.add(l3);


        emailField = new JTextField();
        emailField.setFont(new Font("Serif",Font.PLAIN,18));
        emailField.setBounds(260,215,270,35);
        P2.add(emailField);


        //password

        l4 = new JLabel("Password : ");
        l4.setFont(new Font("Serif",Font.PLAIN,20));
        l4.setForeground(Color.black);
        l4.setBounds(155,280,200,35);
        P2.add(l4);

        passwordField = new JPasswordField();
        passwordField.setEchoChar('*');
        passwordField.setFont(new Font("Serif",Font.PLAIN,19));
        passwordField.setBounds(260,285,270,27);
        P2.add(passwordField);



        // ----------------- Panel 03 Set Up ------------------------

        l5 = new JLabel("Enter your new password : ");
        l5.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,23));
        l5.setForeground(Color.black);
        l5.setBounds(65,130,480,35);
        P3.add(l5);


        //new password
        l6 = new JLabel("New password : ");
        l6.setFont(new Font("Serif",Font.PLAIN,20));
        l6.setForeground(Color.black);
        l6.setBounds(125,210,200,35);
        P3.add(l6);


        newPasswordField = new JPasswordField();
        newPasswordField.setEchoChar('*');
        newPasswordField.setFont(new Font("Serif",Font.PLAIN,20));
        newPasswordField.setBounds(260,215,270,27);
        P3.add(newPasswordField);


        //retype password
        l7 = new JLabel("Retype password : ");
        l7.setFont(new Font("Serif",Font.PLAIN,20));
        l7.setForeground(Color.black);
        l7.setBounds(105,280,200,35);
        P3.add(l7);

        pa3 = new JPasswordField();
        pa3.setEchoChar('*');
        pa3.setFont(new Font("Serif",Font.PLAIN,20));
        pa3.setBounds(260,285,270,27);
        P3.add(pa3);


        //back button
        back2 = new JButton("Back");
        back2.setFont(new Font("Serif",Font.BOLD,20));
        back2.setBackground(Color.orange);
        back2.setBounds(40, 420, 100, 35);
        back2.addActionListener(this);
        back2.setFocusable(false);
        back2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P3.add(back2);


        //confirm button
        confirmButton = new JButton("Confirm");
        confirmButton.setFont(new Font("Serif",Font.BOLD,20));
        confirmButton.setBackground(Color.orange);
        confirmButton.setBounds(570, 420, 130, 35);
        confirmButton.addActionListener(this);
        confirmButton.setFocusable(false);
        confirmButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P3.add(confirmButton);


        //checkbox
        c1 = new JCheckBox("Show password");
        c1.setFont(new Font("Serif",Font.PLAIN,16));
        c1.setForeground(Color.black);
        c1.setBackground(new Color(219,219,219));
        c1.setBounds(260,320,270,38);
        c1.addActionListener(this);
        c1.setFocusable(false);
        c1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(c1);


        this.add(P1);
        this.add(P2);

        setVisible(true);

    }



    public void actionPerformed(ActionEvent ae)
    {

        if(ae.getSource()==back1)
        {
            this.setVisible(false);
            new userinfo();
        }
        else if (ae.getSource() == back2)
        {
            P3.setVisible(false);
            this.add(P2);
            P2.add(c1);
            P2.setVisible(true);
        } else if(ae.getSource()==continueButton)
        {

            if(emailField.getText().isEmpty()|| passwordField.getText().length() <=0)
            {
                JOptionPane.showMessageDialog(this,"Fill all information");
            }

            else
            {
                try
                {
                    String email = emailField.getText();
                    String password = new String(passwordField.getPassword());

                    Conn conn = new Conn();

                    String query = "SELECT * FROM registration WHERE email = '"+email+"' and password = '"+password+"'";

                    ResultSet rs = conn.s.executeQuery(query);

                    if(rs.next())
                    {
                        P2.setVisible(false);
                        this.add(P3);
                        P3.add(c1);
                        P3.setVisible(true);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(this, "Invalid email or password!");
                    }

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }

        else if(ae.getSource()==confirmButton)
        {

            if(newPasswordField.getText().isEmpty() || pa3.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(this,"Fill all information");
            }
            else if(!(newPasswordField.getText()).equals(pa3.getText()))
            {
                JOptionPane.showMessageDialog(this," Password doesn't match ");
            }
            else
            {
                String newPassword = new String(newPasswordField.getPassword());
                String email = emailField.getText();

                try
                {

                    Conn conn = new Conn();

                    // Corrected to use executeUpdate
                    String query1 = "SET SQL_SAFE_UPDATES = 0";
                    String query = "UPDATE registration SET password = '"+newPassword+"' WHERE email = '"+email+"'";

                    // Execute the first query
                    conn.s.executeUpdate(query1);
                    // Execute the update query
                    int rowsAffected = conn.s.executeUpdate(query);

                    if(rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null,"Password Successfully Changed !");
                        this.dispose();
                        new Buses();
                    } else {
                        JOptionPane.showMessageDialog(null,"Password didn't change !");
                    }

                    // What's that problem below code ?
                    /*
                    Conn conn = new Conn();

                    String query1 = "SET SQL_SAFE_UPDATES = 0";
                    String query = "UPDATE registration SET password = '"+newPassword+"' WHERE email = '"+email+"'";

                    conn.s.executeUpdate(query1);
                    ResultSet rs = conn.s.executeQuery(query);

                    if(rs.next())
                    {
                        JOptionPane.showMessageDialog(null,"Password Successfully Change !");

                        new Buses();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Password doesn't Change !");
                    }
                    */
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
        }

        if(c1.isSelected())
        {
            passwordField.setEchoChar((char)0);
            newPasswordField.setEchoChar((char)0);
            pa3.setEchoChar((char)0);

        }
        else
        {
            passwordField.setEchoChar('*');
            newPasswordField.setEchoChar('*');
            pa3.setEchoChar('*');
        }

    }


    public static void main(String [] args)
    {
        passwordChange p = new passwordChange();

    }







}
