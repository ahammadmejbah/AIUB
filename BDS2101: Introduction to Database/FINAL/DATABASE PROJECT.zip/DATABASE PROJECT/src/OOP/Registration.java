package OOP;
import data.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.SQLException;


class Registration implements ActionListener
{

    private JFrame frame;

    private JTextField nameField, emailField;

    private JPasswordField passwordField;

    private JComboBox<String> genderBox;


    public Registration()
    {

        // frame layout
        frame = new JFrame("Registration");
        frame.setSize(750, 510);
        frame.setLayout(null);


        // user name
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 50, 100, 30);
        frame.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150, 50, 200, 30);
        frame.add(nameField);




        //email
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 100, 100, 30);
        frame.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(150, 100, 200, 30);
        frame.add(emailField);




        //password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 150, 100, 30);
        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 150, 200, 30);
        frame.add(passwordField);




        //gender
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(50, 200, 100, 30);
        frame.add(genderLabel);

        String[] genders = {"Male", "Female", "Other"};
        genderBox = new JComboBox<>(genders);
        genderBox.setBounds(150, 200, 200, 30);
        genderBox.setBorder(null);
        frame.add(genderBox);



        //register button
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(150, 250, 100, 30);
        registerButton.setBorder(null);
        registerButton.addActionListener(this);
        frame.add(registerButton);



        //clear frame
        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(310, 250, 100, 30);
        clearButton.setBorder(null);
        clearButton.addActionListener(this);
        frame.add(clearButton);



        // link up login page
        JLabel loginLabel = new JLabel("Already Registered? Login");
        loginLabel.setForeground(Color.BLUE);
        loginLabel.setBounds(200, 300, 200, 30);
        loginLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new Login();
            }
        });
        frame.add(loginLabel);





        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);


    }


    /*
    public void actionPerformed(ActionEvent e)
    {

        if (e.getSource() instanceof JButton)
        {

            JButton button = (JButton) e.getSource();

            if (button.getText().equals("Register")) {

                register();

            } else if (button.getText().equals("Clear")) {

                clearFields();

            }

        }

    }

    private void register()
    {

        String name = nameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String gender = (String) genderBox.getSelectedItem();


        // Check for empty fields
        if (name.isEmpty() || email.isEmpty() || password.isEmpty())
        {
            JOptionPane.showMessageDialog(frame, "Please fill all fields!");
            return;
        }

        // Check for existing email
        if (isEmailExists(email))
        {
            JOptionPane.showMessageDialog(frame, "User with this email already exists!");
            return;
        }

        User newUser = new User(name, email, password, gender);


        try (FileWriter writer = new FileWriter("src\\data\\userdata.txt", true))
        {
            writer.write(newUser.getName() + "," + newUser.getEmail() + "," + newUser.getPassword() + "," + newUser.getGender() + "\n");

            JOptionPane.showMessageDialog(frame, "Registration Successful!");

            frame.dispose();
            new Login();

        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }

    }


    private boolean isEmailExists(String email)
    {

        try (BufferedReader reader = new BufferedReader(new FileReader("src\\data\\userdata.txt"))) {

            String line;

            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split(",");

                if (parts.length > 1 && parts[1].equals(email))
                {
                    return true;
                }

            }

        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }

        return false;

    }

    */


    public void actionPerformed(ActionEvent ae)
    {
        String text = ae.getActionCommand();

        if(text.equals("Register"))
        {
            String name, email, password, gender;

            name = nameField.getText();
            email = emailField.getText();
            password = new String(passwordField.getPassword());
            gender = (String) genderBox.getSelectedItem();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty())
            {
                JOptionPane.showMessageDialog(frame, "Please fill all fields!");
                return;
            }
            else
            {
                try
                {
                    Conn conn = new Conn();

                    String query = "insert into registration values('"+name+"','"+email+"','"+password+"','"+gender+"')";

                    conn.s.executeUpdate(query);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

                JOptionPane.showMessageDialog(null, "User Details Added Successfully");

                frame.dispose();
                new Registration();

            }

        }
        else if(text.equals("Clear"))
        {
            clearFields();
        }
    }

    private void clearFields()
    {
        nameField.setText("");
        emailField.setText("");
        passwordField.setText("");
        genderBox.setSelectedIndex(0);

    }




    public static void main(String[] args)
    {
        new Registration();
    }

}
