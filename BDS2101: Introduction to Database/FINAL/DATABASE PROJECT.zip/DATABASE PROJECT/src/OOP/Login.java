package OOP;

import GUI.*;
import data.Conn;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;

public class Login implements ActionListener
{
    private JFrame frame;
    private JPanel P1,P2;
    private JLabel l1,l2,l3,l4,l5;
    private JTextField t1;
    private JButton b1,b2;
    private JPasswordField pa1;

    JCheckBox c1;
    private ImageIcon icon, logo;
    private JTextField emailField;
    private JPasswordField passwordField;

    private Cursor cursor;
    private JButton loginButton,registerButton;


    public Login()
    {

        // --------------Frame Layout Setup-----------
        frame = new JFrame("Login");
        frame.setSize(750, 510);
        frame.setLayout(null);


        cursor = new Cursor(Cursor.HAND_CURSOR);

        //=======================================================


        JLabel emailLabel = new JLabel("Email");
        emailLabel.setForeground(Color.red);
        emailLabel.setFont(new Font("Serif",Font.BOLD,18));
        emailLabel.setForeground(Color.black);
        emailLabel.setBounds(250, 83, 100, 30);
        frame.add(emailLabel);


        emailField = new JTextField();
        emailField.setBounds(350, 83, 200, 30);
        frame.add(emailField);


        // Password
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Serif",Font.BOLD,18));
        passwordLabel.setForeground(Color.black);
        passwordLabel.setBounds(250, 133, 100, 30);
        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setEchoChar('*');
        passwordField.setBounds(350, 133, 200, 30);
        frame.add(passwordField);



        // ==================Button================200, 250, 100, 30

        loginButton = new JButton("Login");
        loginButton.setBounds(340, 185, 100, 30);
        loginButton.setCursor(cursor);
        loginButton.setBorder(null);
        loginButton.addActionListener(this);
        frame.add(loginButton);

        registerButton = new JButton("Register");
        registerButton.setBounds(600, 185, 100, 30);
        registerButton.addActionListener(this);
        registerButton.setCursor(cursor);
        registerButton.setBorder(null);
        frame.add(registerButton);

        JButton back = new JButton("back");
        back.setBounds(50, 20, 100, 30);
        back.setCursor(cursor);
        back.setBorder(null);
        frame.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new HomePage();
            }
        });


        icon = new ImageIcon(getClass().getResource("/image/busgif11.gif"));
        l3 = new JLabel(icon);
        l3.setBounds(0,0,icon.getIconWidth(), icon.getIconHeight());
        frame.add(l3);


        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);



    }



    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource() == loginButton)
        {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            try
            {
                Conn conn = new Conn();

                String query = "SELECT * FROM registration WHERE email = '"+email+"' and password = '"+password+"'";

                ResultSet rs = conn.s.executeQuery(query);

                if(rs.next())
                {
                    JOptionPane.showMessageDialog(null,"Login Successfully ! ");
                    new Buses();
                    frame.setVisible(false);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                    frame.setVisible(false);
                    new Login();
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else if (ae.getSource() == registerButton)
        {
            frame.setVisible(false);
            new Registration();
        }

    }

    public static void main(String[] args) {
        new Login();
    }

}
